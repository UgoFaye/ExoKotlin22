

The function must be named "main"
fun main() {
    println("It works!") This statement prints a text
}