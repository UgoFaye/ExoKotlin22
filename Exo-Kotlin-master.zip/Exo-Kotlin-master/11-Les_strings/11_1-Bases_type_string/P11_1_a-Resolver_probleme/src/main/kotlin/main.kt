
fun main() {
    val name = 10 + "years' + "ago" we were "s in London"

    println(name)
}