fun main() {
    solution(listOf("Mustard", "Cheese", "Eggs", "Cola", "Eggs"), "Eggs")
}

fun solution(products: List<String>, product: String) {
    // put your code here
}
