fun main() {
    solution(listOf(8, 11, 3, 2))
}

fun solution(numbers: List<Int>) {
    // put your code here
}

