fun main() {
    println(solution(listOf("Fred", "Pola", "Mike", "Fred"), "Fred"))
}

fun solution(strings: List<String>, str: String): Int {
    // put your code here
}
