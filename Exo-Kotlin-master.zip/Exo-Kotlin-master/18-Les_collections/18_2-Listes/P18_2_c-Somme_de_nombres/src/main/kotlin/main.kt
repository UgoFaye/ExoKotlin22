fun main() {
    println(solution(listOf(3, 2, 15)))
}

fun solution(numbers: List<Int>): Int {
    // put your code here
}