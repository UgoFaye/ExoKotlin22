fun main() {
    val myWishList = mapOf("watch" to 120, "jumper" to 80, "smartphone" to 350)
    val limit = 200
    println(makeMyWishList(myWishList, limit))
}

fun makeMyWishList(wishList: Map<String, Int>, limit: Int): MutableMap<String, Int> {
    // write here
}

