fun main() {
    val studentsMarks = mutableMapOf<String, Int>()

}