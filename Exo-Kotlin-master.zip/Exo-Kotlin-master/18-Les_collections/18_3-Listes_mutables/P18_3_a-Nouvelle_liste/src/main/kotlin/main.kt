fun main() {
    println(solution(listOf(8, 11, 13, 14), 1).joinToString())
}

fun solution(numbers: List<Int>, number: Int): MutableList<Int> {
    // put your code here
}
