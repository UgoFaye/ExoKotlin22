fun main() {
    println(solution(setOf(8, 11, 12, 13), setOf(8, 12)))
}

fun solution(numbers1: Set<Int>, numbers2: Set<Int>): Int {
    // put your code here
}