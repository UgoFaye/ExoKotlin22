fun main() {
    println(evenFilter(setOf(1, 2, 3, 4, 5, 6, 7, 8)))
}

fun evenFilter(numbers: Set<Int>): Set<Int> {
    // put your code here
}
