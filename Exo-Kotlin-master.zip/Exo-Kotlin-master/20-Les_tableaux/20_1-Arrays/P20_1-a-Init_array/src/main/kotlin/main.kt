fun main() {
    val characters = // ...

        println(characters.joinToString())
}