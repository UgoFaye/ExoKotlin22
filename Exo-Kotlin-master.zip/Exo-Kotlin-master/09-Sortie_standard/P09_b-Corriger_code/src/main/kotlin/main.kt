fun main() {
    println(1, 2, 3...)
    printLin("Line print here ")
    lnPrint(42)
    printLn("Pay attention to")
    println("syntax")
}


