fun main() {
    println("Learn Kotlin")
}

