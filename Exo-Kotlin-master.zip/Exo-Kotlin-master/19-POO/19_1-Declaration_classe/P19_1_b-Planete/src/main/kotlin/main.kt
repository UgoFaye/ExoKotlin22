// write your code here


fun main() {
    val kotlinPlanet = Planet()
    kotlinPlanet.star = "Java"
    kotlinPlanet.mass = 2.0
    kotlinPlanet.numberOfSatellites = 0
}