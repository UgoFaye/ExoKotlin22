fun main() {
    // do not touch the lines above
    // declare and initialize a variable here


    // do not touch the lines below
    println(bigNumber)
}

