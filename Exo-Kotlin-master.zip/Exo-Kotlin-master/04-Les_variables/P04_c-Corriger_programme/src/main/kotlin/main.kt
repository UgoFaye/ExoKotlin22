fun main() {
    val string = "Hello, World!"
    string = "Hello, Kotlin!"
    println(string)
}

