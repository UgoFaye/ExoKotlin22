

fun main() {
    // Do not touch the line above
    val number = 2
    number = 5
    // Do not touch the lines below
    print(number)
}