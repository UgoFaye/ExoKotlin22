fun main() {
    // Fix declaration. Do not touch the lines above
    a = 512343
    b = 3431231
    // Do not touch the lines below
    println("$a $b")
}
