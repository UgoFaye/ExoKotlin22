fun main() {
    val numbers = // put your code here

        // do not touch the lines below
        println(numbers.joinToString())
}
