fun main() {
    val numbers = // ...

        // do not touch the lines below
        println(numbers.joinToString())
}
