fun main() {
    println(createMutableList().joinToString())
}

fun createMutableList(): MutableList<String> {

    val capitals = // write your code here
        return capitals
}



