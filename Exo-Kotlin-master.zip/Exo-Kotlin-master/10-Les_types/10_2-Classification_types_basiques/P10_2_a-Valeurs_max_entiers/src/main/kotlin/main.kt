fun main() {
    println(Byte.MAX_VALUE)
    println(Short.MAX_VALUE)
    println(Int.MAX_VALUE)
    println(Long.MAX_VALUE)
}
