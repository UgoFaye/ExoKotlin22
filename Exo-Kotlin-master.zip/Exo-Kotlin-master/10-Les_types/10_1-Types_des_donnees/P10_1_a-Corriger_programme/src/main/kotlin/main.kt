fun main() {
    val number: String = 100
    println(number)
}

