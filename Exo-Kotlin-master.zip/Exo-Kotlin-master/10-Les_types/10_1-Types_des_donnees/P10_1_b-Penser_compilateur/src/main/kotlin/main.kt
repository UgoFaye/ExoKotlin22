

fun main() {

    // put your code above
    println("My name is $first $last and I’m $age years old")
}