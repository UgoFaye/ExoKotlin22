fun main() {
    val var: String = "Kotlin "
    val part2 = is a cross-platform
    String val = ", statically typed, "
    val part4 = "general-purpose programming language with type coercion."

    print(part1)
    print(part2)
    print(part3)
    print(part4)
}