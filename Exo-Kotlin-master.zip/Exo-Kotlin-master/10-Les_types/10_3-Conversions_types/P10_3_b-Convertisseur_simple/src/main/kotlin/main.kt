fun main() {
    val number = readln()
    println(number.toInt())
    println(number.toDouble())
    println(number.toBoolean())
}