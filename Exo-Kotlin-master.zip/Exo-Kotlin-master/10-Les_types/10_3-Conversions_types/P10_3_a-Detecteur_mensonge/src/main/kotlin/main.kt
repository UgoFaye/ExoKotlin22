fun main() {
    val n = readln()
    print(n.toBoolean())
}