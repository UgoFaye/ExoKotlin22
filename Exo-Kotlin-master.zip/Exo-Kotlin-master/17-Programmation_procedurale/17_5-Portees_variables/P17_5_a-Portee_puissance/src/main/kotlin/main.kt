fun main() {
    // change the code below

    for (i in 2..10) {
        var thirteen = 13L
        thirteen *= 13
        println(thirteen)
    }
}