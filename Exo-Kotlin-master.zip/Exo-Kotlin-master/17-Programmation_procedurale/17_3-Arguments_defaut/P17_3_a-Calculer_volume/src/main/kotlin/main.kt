fun getVolume(...){
    //TODO
}

fun main() {
    println(getVolume(1))
}