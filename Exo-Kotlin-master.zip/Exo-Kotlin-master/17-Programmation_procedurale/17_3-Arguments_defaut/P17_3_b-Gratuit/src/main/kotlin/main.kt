fun tip(bill: Int, percentage: Int): Int {
    // TODO
}

fun main() {
    println(tip(100))
    println(tip(100, 5))
}