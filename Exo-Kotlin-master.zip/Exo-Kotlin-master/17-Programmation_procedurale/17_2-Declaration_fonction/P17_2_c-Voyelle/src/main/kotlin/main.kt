// write your function here

fun main() {
    val letter = readLine()!!.first()

    println(isVowel(letter))
}
