// This is the totalLembas() function. It just counts the total number of lembas.
// Do not change this code
fun totalLembas(first: String, second: String) {
    print(first.toInt() + second.toInt())
}

fun main() {
    val breadFromFrodo = readln()
    val breadFromSam = readln()

    // write your code here

}