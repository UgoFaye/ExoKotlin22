fun url(host: String, port: Int): String {
    // TODO
}

fun main() {
    println(url())
    println(url("192.168.1.1", 2626))
}